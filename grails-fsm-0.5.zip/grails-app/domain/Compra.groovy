import java.io.Serializable;

class Compra implements Serializable {
	transient def mensajesService
	
	int cantidad
    float iva
    float tramitacion
    float envio

    float importeUnitario = 0
    float importeTotal = 0
    String estado = 'comprada'


    static belongsTo = [
        ]

    static constraints = {

        importeUnitario()
        importeTotal()
    }

    static fsm_def = [
        estado : [
            comprada : { flow ->
            	flow.on('solicitar_envio') { // Vendedor lanza este evento al confirmar dirección/recogida
            		from('comprada').to('a_recoger')
            	}
            	flow.on('confirmar_envio') {  // Quartz/UPS lanzan este evento
            		from('a_recoger').to('en_transito').act({
            			mensajesService.avisoDeEnTransito(id)
            		})
            	}
            	flow.on('fallo_recogida') {
            		from('a_recoger').to('comprada').act({
            			mensajesService.avisoDeRecogidaFallida(id)
                	})
            	}
            	flow.on('confirmar_entrega') { // Quartz/UPS confirman entrega final
            		from('en_transito').to('entregada').act({
            			mensajesService.avisoDeEntregaRealizada(id)
            		})
            	}
    		}
    	]
    ]

    public String estadoDescripcion() {
    	estadoDescripcion(estado);
    }

    public static String estadoDescripcion(String estado_id) {
    	String descripcion = "ERROR";
    	switch (estado_id) {
    	case CompraEstado.COMPRADA:
    		descripcion = 'Comprada';
    		break;
    	case CompraEstado.A_RECOGER:
    		descripcion = 'A Recoger';
			break;
    	case CompraEstado.EN_TRANSITO:
    		descripcion = 'En Transito';
			break;
    	case CompraEstado.ENTREGADA:
    		descripcion = 'Entregada';
			break;
		}
    	return descripcion;
    }

    public static def describirEstado(String estado_id) {
    	[id: estado_id, descripcion: estadoDescripcion(estado_id)] 
    }
    
    public static def estados() {
    	def resultado = [];
    	resultado << describirEstado(CompraEstado.COMPRADA)
      	resultado << describirEstado(CompraEstado.A_RECOGER)
      	resultado << describirEstado(CompraEstado.EN_TRANSITO)
      	resultado << describirEstado(CompraEstado.ENTREGADA)
        return resultado;
    }
    
}

public class CompraEstado {
	public static String COMPRADA = 'comprada';
	public static String A_RECOGER = 'a_recoger';
	public static String EN_TRANSITO = 'en_transito';
	public static String ENTREGADA = 'entregada';
}