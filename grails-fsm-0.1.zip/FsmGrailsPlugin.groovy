import FsmSupport
import FsmSupportException

import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.commons.metaclass.*


class FsmGrailsPlugin {
    // the plugin version
    def version = "0.1"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.1.1 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    def author = "Jorge Uriarte"
    def authorEmail = "jorge.uriarte@omelas.net"
    def title = "Finite State Machine behaviour for domain classes"
    def description = '''\\
        This plugin allow definition of simple workflows attached to domain classes, including
        states, events, transitions and conditions.
        Current workflow's state will be held in domain class' property that must be defined.
        Multiple workflows can be defined on every domain class.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/Fsm+Plugin"

    final def FSMDEF="fsm_def"
    
    def doWithSpring = {
        // TODO Implement runtime spring config (optional)
    }

    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)
    }

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional)
    }

    def doWithDynamicMethods = { ctx ->

        // Closure for the 'fire' methods to add to the domain classes
        Closure fireClosure = {String flow, String event ->
            // Fix current delegate so inner closures will work
            def targetObject = delegate
            def flowdef = GrailsClassUtils.getStaticPropertyValue(delegate.class, FSMDEF )
            if (flowdef[flow] == null)
                throw new FsmSupportException("Can't fire on flow '${flow}' which is not defined in '${targetObject.class}'")
            // 
            // If flow has not been already initialized, will do it (we'll also
            // take the time to intialize the rest of the flows ;) )
            if (targetObject."_fsm${flow}" == null)
                flowdef.each { p, d ->
                    d.each { s, c ->
                        if (targetObject."_fsm${p}"== null) {
                            targetObject["_fsm${p}"] = new FsmSupport(targetObject, p, s)
                            c(targetObject."_fsm${p}".record())
                        }
                    }
                }
            return targetObject."_fsm${flow}".fire(event)
        }

        // Will add the closure where needed
        application.domainClasses.each {domainClass ->
            MetaClassRegistry registry = GroovySystem.metaClassRegistry
            def fsm = GrailsClassUtils.getStaticPropertyValue(domainClass.clazz, FSMDEF )
            if (fsm) {
                // Will create the proper FsmSupport instance!
                fsm.each {p, definition ->
                    definition.each { start, defclosure ->
                        if (!domainClass.metaClass.getMetaProperty(p))
                            throw new FsmSupportException("Error in FSM definition: '${domainClass}' does not have '${p}' property to hold defined workflow status!")

                        // Modify the metaclass so new instances will have new behaviour!!
                        domainClass.metaClass.setProperty("_fsm${p}", null)  // internal, will hold FsmSupport instance
                        domainClass.metaClass.fire = fireClosure
                        domainClass.metaClass."fire_${p}" = fireClosure.curry(p)
                    }
                }
            }
        }
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
