/**
 * Domain class to held some test of the FsmSupport
 *
 */
class FsmSupportDummy {

    def name
    def estado = 'publicada'
    def status
    def mood

    def amount  // A number > 0 will allow the status flow to start
    
    static fsm_def = [
        estado : [
            publicada : { flow ->
                flow.on('restringir') {
                    from('publicada').to('restringida')
                }
                flow.on('reactivar') {
                    from('restringida').to('publicada')
                }
                flow.on('caducar') {
                    from('restringida').to('caducada')
                    from('publicada').to('caducada')
                }
                flow.on('comprar') {
                    from('publicada').when({
                            cantidadDisponible > 0
                        }).to('publicada')
                    from('publicada').to('vendida')
                }
            }
        ],
        mood : [
            none : { flow ->
                flow.on ('up') {
                    from('none').when({
                            status == 'running'  // Depends on second flow!!
                        }).to('high')
                    from('low').to('high')
                    from('high').to('high')
                    from('none').to('none') // Order is CRITICAL!!
                }
                flow.on('down') {
                    from('none').when({
                            status == 'running'
                        }).to('low')
                    from('low').to('low')
                    from('high').to('low')
                    from('none').to('none') // Order is CRITICAL!!
                }

            }
        ],
        status : [
            initial : { flow ->
                flow.on('launch') {
                    from('initial').when({
                            isSomethingPending() && amount > 0
                        }).to('running')
                    from('initial').to('initial')
                }
                flow.on('stop') {
                    from('running').to('stopped')
                }
                flow.on('continue') {
                    from('stopped').to('running')
                }
                flow.on('finish') {
                    from('stopped').to('finished')
                    from('running').to('finished')
                }
            }
        ]
    ]

    /*
     * Sample method to call from conditions!!
     */
    def isSomethingPending() {
        return true
    }
}
